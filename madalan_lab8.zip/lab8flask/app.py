from flask import Flask,render_template,flash, redirect,url_for,session,logging,request
from flask_sqlalchemy import SQLAlchemy
from dbsetup import app,db
from model import user
from form import CustomerRegistrationForm,CustomerLoginForm
app.config['SECRET_KEY'] = 'hardsecretkey'




@app.route("/",methods=["GET", "POST"])
def login():
    form=CustomerLoginForm()
    if form.validate_on_submit():
        mail = form.email.data
        password = form.password.data
        
        login = user.query.filter_by(email=mail, password=password).first()
        if login is not None:
            return render_template("SecretPage.html")
    return render_template("login.html",form=form)

@app.route("/register", methods=["GET", "POST"])
def register():
    form=CustomerRegistrationForm()
    if form.validate_on_submit():
        fname = form.firstname.data
        lname = form.lastname.data
        #lname = request.form['lname']
        mail = form.email.data
        password = form.password.data
        
        print(fname,password)
        repassword = form.confirm.data
        if(password==repassword):
            register = user(firstname = fname,lastname=lname, email = mail, password = password)
            db.session.add(register)
            db.session.commit()

        return render_template("Thankyou.html")
    return render_template("register.html",form=form)


if __name__ == "__main__":
    app.run(debug=True)
