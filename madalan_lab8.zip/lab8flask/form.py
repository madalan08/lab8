from wtforms import StringField, TextAreaField, PasswordField, SubmitField, IntegerField, validators, Form, ValidationError
from flask_wtf.file import FileRequired, FileAllowed, FileField
from flask_wtf import FlaskForm
from model import user
import os
def checkSmall(s):
  for char in s:
    k = char.islower() 
    if k == True:
        return True
  return False
def checkCaptial(s):
  for char in s:
    k = char.isupper() 
    if k == True:
        return True
  return False
def checkNumber(s):
  return s[-1].isdigit()

class CustomerRegistrationForm(FlaskForm):
    #name = StringField('Name', [validators.DataRequired()])
    firstname = StringField('First name', [validators.DataRequired()])
    lastname = StringField('Last name', [validators.DataRequired()])
    email = StringField("Email", validators=[validators.Email(), validators.DataRequired()])
    password = PasswordField('Password', [validators.DataRequired(), validators.EqualTo('confirm', message="Both passwords should match")])
    confirm = PasswordField("Re-Password", [validators.DataRequired()])        
    #submit = SubmitField("Register")
    def validate_email(self, email):
        if user.query.filter_by(email=email.data).first():
            raise ValidationError("Email already Exists.")
    def validate_password(self, password):
        s=password.data
        error=""
        if(not checkSmall(s)):
          error+="You did not use an lowercase character"+os.linesep
        if(not checkCaptial(s)):
          error+="You did not use an uppercase character"+os.linesep
        if(not checkNumber(s)):
          error+="You did not end your password with a number"+os.linesep
        if(len(s)<8):
          error+="password should be at least 8 characters"+os.linesep
        if len(error)>1:
            raise ValidationError(error)

class CustomerLoginForm(FlaskForm):
    email = StringField("Email", validators=[validators.Email(), validators.DataRequired()])
    password = PasswordField('Password', [validators.DataRequired()])


